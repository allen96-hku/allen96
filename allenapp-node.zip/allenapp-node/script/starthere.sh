#!/bin/bash

~/clear.sh

cd ..
npm install

./startFabric.sh

#node enrollAdmin.js
#node registerUser.js