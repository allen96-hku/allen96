#!/bin/bash

./3_2variableLengthUser.sh
./4_3variableLengthAC.sh
./7_1_9_2_1singlePAYtoMany.sh
./5_2delACfrom64users.sh
./6_1del64users.sh